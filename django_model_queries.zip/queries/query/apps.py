from django.apps import AppConfig


class QueryConfig(AppConfig):
    name = 'query'
